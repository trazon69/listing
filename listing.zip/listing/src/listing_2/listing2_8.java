package listing_2;

public class listing2_8 {
    public static void main(String[] args){
        System.out.println("Первая строка\nВторая строка");
        System.out.println("A\tB\tC");
        System.out.println("D\tE\tF");
    }
}
