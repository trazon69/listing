package listing_2;

public class listing2_4 {
    public static void main (String[] args) {
        double i, j, d;
        i = 50;
        j = 150;
        if (i!= 0){
            System.out.println("Делитель не равен нулю");
            d = j / i;
            System.out.println("j / i равно " + d);
        }
    }
}

