package listing_2;

public class listing2_14 {
    public static void main(String[] args){
        byte x, z;
        int y;

        x = 5;
        y = x * x;

        z = (byte) (x * x);
        System.out.println(z);
    }
}
