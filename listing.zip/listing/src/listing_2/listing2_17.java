package listing_2;

public class listing2_17 {
    public static void main(String[] args) {
        char ch = 'Я';
        do {
            ch--;
            System.out.println(ch);
        }    while ((ch >= 'А'));
    }
}
