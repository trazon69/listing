package listing_2;

public class listing2_16 {
    public static void main(String[] args) {
        char ch = 'а';
        while (ch <= 'я')  {
            System.out.println(ch);
            ch++;
        }
    }
}
