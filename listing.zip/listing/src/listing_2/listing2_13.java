package listing_2;

public class listing2_13 {
    public static void main(String[] args){
        long l = 10;
        double d = l;
    }
}
