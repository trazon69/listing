package listing_2;

public class listing2_7 {
    public static void main(String[] args){
        boolean b;

        b = false;
        System.out.println("b равно " + b);
        b = true;
        System.out.println("b равно" + b);

        if (b) System.out.println("выражение 10 > 9 имеет значение " + (10 > 9));
        System.out.println("Выражение 10 > 9 имеет значение " + (10 > 9));
    }
}