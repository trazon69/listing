package listing_2;

public class listing2_12 {
    public static void main(String[] args){
        int inresult, iremain;
        double dresult, dremain;

        inresult = 10 / 3;
        iremain = 10 % 3;

        System.out.print("Частное от деления 10 / 3 равно ");
        System.out.println(inresult + ", остаток равен " + iremain);

        dresult = 10.0 / 3.0;
        dremain = 10.0 % 3.0;

        System.out.print("Частное от деления 10.0 / 3.0 равно ");
        System.out.println(dresult + ", остаток равен " + dremain);

    }
}
